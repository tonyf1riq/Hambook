# HamBook Android (v1.7.1)

WebView plein écran qui embarque `app/src/main/assets/index.html`.

## Obtenir l'APK
**A. Android Studio** : File > Open (ce dossier) > Build > Build APK(s).
  Résultat : `app/build/outputs/apk/debug/app-debug.apk`.

**B. Sans rien installer (GitHub Actions)** : poussez ce dossier dans un dépôt GitHub,
  onglet Actions > "Build APK" > artefact `HamBook-debug-apk`.

Installation : copier l'APK sur le téléphone et autoriser les sources inconnues.

## Mettre à jour HamBook
Remplacer `app/src/main/assets/index.html`, incrémenter `versionCode`/`versionName`
dans `app/build.gradle`, recompiler.

## Notes
- Les exports (JSON/ADIF/Cabrillo) sont enregistrés dans Téléchargements.
- Les imports ouvrent le sélecteur de fichiers Android.
- Le CORS est levé pour les pages locales : les appels HamQSL/POTA fonctionnent sans proxy.
- Les liens externes (QRZ, POTA...) s'ouvrent dans le navigateur.
